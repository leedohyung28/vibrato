const NewMusicPage = () => {
  return <h2>최신 트랙</h2>;
};

export default NewMusicPage;
